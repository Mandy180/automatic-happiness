#include "program1.h"
#include "schedule.h"
int main()
{
    event Jessica; //ALL of the events for Jessica to attend
    char name[100];
    cout << "Please add the name of this event: " << endl;
    cin.get(name, 100, '\n');
    cin.ignore(100, '\n');

    int value = 0;
    cout << "Please enter the cost of attending this event : " << endl;
    cin >> value;
    cin.ignore(100, '\n');

    char info[100];
    cout << "Please enter the information about this event: " << endl;
    cin.get(info, 100, '\n');
    cin.ignore(100, '\n');

    Jessica.add_event(name, value, info);


















    return 0;
}
