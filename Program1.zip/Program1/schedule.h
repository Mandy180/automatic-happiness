#include <iostream>
#include <cctype>
#include <cstring>
#include <cstdlib>
using namespace std;

struct c_node //CLL
{
    char * name_of_couple;
    char * wedding_date;
    c_node * next;
};
class attending_weddings
{
    public:
        attending_weddings();
        ~attending_weddings();
        void add_new_weddings();
        void copy_weddings();
        void display();
        void remove_all();
        void remove();
    protected:
        c_node * rear;
};



class scheduling_hair_appointments
{
    public:
        scheduling_hair_appointments();
        ~scheduling_hair_appointments();
        void add_hair_salon();
        void add_dates();
        void find_the_cost();
    protected:
        int size_of_array[10];
        int cost;
        char * name_of_salon;
};

class buying_groceries
{
    public:
        buying_groceries();
        ~buying_groceries();
        void select_store();
        void add_grocery_list();
    protected:
        char * list_of_groceries;
};
