#include <iostream>
#include <cctype>
#include <cstring>
#include <cstdlib>
using namespace std;

//This header file contains all the information about this assignment
//The three events for this summer is attending weddings, scheduling hair appointments, and buying groceries.
//The overall problem is scheduling these three events in one application. 
//The general classes are: person, budget, date
//The class budget is derived from the person
//the class person "has a" relationship for the availability

class event //base class
{
    public:
        event();
        event( char * name, char * info);
        ~event();
        void change_event();
        void add_event(char * name, int value, char * info);
        int check_event(char * name);
    protected:
        char * event_name;
        int cost;
        char * information_about_event;
};
class seasonal_event: public event //derived from base class event
{
    public:
        seasonal_event();
        ~seasonal_event();
        void change_event();
        void add_event();
        void check_event();
    protected:
        int number_of_days;
        char * list_of_things_to_prepare;

};
class routine_event: public event // derived from the base class event
{
    public:
        routine_event();
        ~routine_event();
        void change_event();
        void add_event();
        void check_event();
    protected:
        char * day_of_the_week;
        int time;
        
};
class neccesary_event: public routine_event //derived from the routine event
{
    public:
        neccesary_event();
        ~neccesary_event();
        void check_amount();
        void add_things_to_do();
        void remove_event();
    private:
        int absolute_budget;
        int left_over_amount;
};


