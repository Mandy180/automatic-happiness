#include "program1.h"

event::event()
{
    event_name = information_about_event = NULL;
    cost = 0;
}
event::event( char * name, char * info)
{
    event_name = new char [strlen(name)+1];
    strcpy(event_name, name);

    information_about_event = new char[strlen(info) +1];
    strcpy(information_about_event, info);
}
event::~event()
{
    if(event_name)
        delete [] event_name;
    if(information_about_event)
        delete [] information_about_event;
}
    
void event::add_event(char * name, int value, char * info)
{
    event_name = new char[strlen(name) +1];
    strcpy(event_name, name);

    information_about_event = new char [strlen(info) +1];
    strcpy(information_about_event, info);
    
    cost = value;

} 
int event::check_event(char * name)
{
    if( strcmp(name, event_name) == 0)
        return 1;
    else
        return 0;
}
    
seasonal_event::seasonal_event()
{
    number_of_days = 0;
    list_of_things_to_prepare = NULL;
}
routine_event::routine_event()
{
    day_of_the_week = NULL;
    time = 0;
}
neccesary_event::neccesary_event()
{
    absolute_budget = 0;
    left_over_amount = 0;
}
